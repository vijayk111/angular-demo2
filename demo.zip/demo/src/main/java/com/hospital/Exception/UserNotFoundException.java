package com.hospital.Exception;

@SuppressWarnings("serial")
public class UserNotFoundException extends Exception{
	public UserNotFoundException(String message){
		super(message);
	}
}
