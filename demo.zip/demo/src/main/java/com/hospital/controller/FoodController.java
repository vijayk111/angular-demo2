package com.hospital.controller;

import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hospital.model.Item;
import com.hospital.services.FoodService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping
public class FoodController {
	
	private static Logger log=LogManager.getLogger(FoodController.class);	
	
	@Autowired
	private FoodService service;		
	
	@GetMapping("/items")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Item> findAll(){
		log.debug("getting items");
		return service.findAll();
	}
	
	@PostMapping("/addtocart")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> addToCart(@RequestBody Item item){
		log.debug(item.getName());
		ResponseEntity<String> responseEntity;
		String response="successfully added!";
		service.addToCart(item);
		responseEntity=new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;	
	}
	
	@GetMapping("/cartItems")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Item> getCartItems(){
		return service.getCartItems();
	}
	
	@GetMapping("/totalcost")
	@CrossOrigin(origins = "http://localhost:4200")
	public int totalCost(){
		return service.totalCost();
	}
	
	@PostMapping("/updateCartItem")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean updateCartItem(@RequestBody Item item){
		log.debug(item.getName());		
		return service.updateCartItem(item);	
	}
		
	@DeleteMapping("/placeOrder")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean placeOrder(){	
		return service.placeOrder();	
	}
	
}
