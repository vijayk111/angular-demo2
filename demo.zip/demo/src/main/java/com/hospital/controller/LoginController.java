package com.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.model.Cart;
import com.hospital.model.Item;
import com.hospital.model.User;
import com.hospital.services.MainService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping
public class LoginController {
	
	@Autowired
	private MainService service;	
	
	
	@GetMapping("/users")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<User> getAllUsers(){
		System.out.println("getting users");
		return service.getAllUsers();
	}
	
	@PostMapping("/userreg")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean userregistration(@RequestBody User user){
		System.out.println("reg users"+"     "+user.getUsername());			
		return service.saveUser(user);
	}
	
	@GetMapping("/items")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Item> findAll(){
		System.out.println("getting items");
		return service.findAll();
	}
	
	@PostMapping("/addtocart")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> addToCart(@RequestBody Item item){
		System.out.println(item.getName());
		ResponseEntity<String> responseEntity;
		String response="successfully added!";
		service.addToCart(item);
		responseEntity=new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;	
	}
	
	@GetMapping("/cartItems")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Item> getCartItems(){
		return service.getCartItems();
	}
	
	@GetMapping("/totalcost")
	@CrossOrigin(origins = "http://localhost:4200")
	public int totalCost(){
		return service.totalCost();
	}
	
	@PostMapping("/updateCartItem")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean updateCartItem(@RequestBody Item item){
		System.out.println(item.getName());		
		return service.updateCartItem(item);	
	}
	
	@DeleteMapping("/placeOrder")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean placeOrder(){	
		return service.placeOrder();	
	}
	
}
