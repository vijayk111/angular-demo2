package com.hospital.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.model.User;
import com.hospital.services.JwtSecurityTokenGenerator;
import com.hospital.services.UserService;


@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {	
	
	private static Logger log=LogManager.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	JwtSecurityTokenGenerator generator;
		
	@PostMapping("/userreg")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<?> userregistration(@RequestBody User user){
		try{
			userService.saveUser(user);
			System.out.println("User registered");
			String response = "User registered successfully";
			return new ResponseEntity<String>(response, HttpStatus.CREATED);
		}			
		catch(Exception e){
			log.debug("User Not registered");
			String response=e.getMessage();
			return new ResponseEntity<String>(response, HttpStatus.CONFLICT);
		}
	}
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<?> login(@RequestBody User user) {
		try {
			System.out.println("validating");
			User u = userService.findByUserIdAndPassword(user.getUsername(), user.getPassword());		
			Map<String, String> map = generator.generateToken(u);
			System.out.println(map);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
		
		catch(Exception e)
		{
			Map<String, String> map =new HashMap<String, String>();
			log.debug("Invalid credentials");
			map.put("message",e.getMessage());
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}		

	}

}
