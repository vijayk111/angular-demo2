package com.hospital.model;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemRepository extends CrudRepository<Item, Integer>{
	
	@Modifying
	@Query("UPDATE Item i SET i.avail=:itemAvail where i.id=:itemId")
	void updateItem(@Param("itemAvail") int itemAvail, @Param("itemId") int itemId);
	
	@Query("from Item i where i.id=:id")
	Item getItemById(@Param("id") int id);
	
	@Modifying
	@Query("UPDATE Item i SET i.quantity=:itemQuantity where i.id=:itemId")
	void updateItemQuantity(@Param("itemQuantity") int itemQuantity, @Param("itemId") int itemId);
}
