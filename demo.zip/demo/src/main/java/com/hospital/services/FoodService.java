package com.hospital.services;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.util.*;
import com.hospital.model.Cart;
import com.hospital.model.CartRepository;
import com.hospital.model.Item;
import com.hospital.model.ItemRepository;


@Service
@Qualifier("service")
public class FoodService {

	
	@Autowired
	private ItemRepository ir;
	
	
	
	@Autowired
	private CartRepository cr;
	
	
	
	@Transactional
	public List<Item> findAll() {
		return (List<Item>) ir.findAll();
	}
			
	
	@Transactional
	public List<Cart> getAllCartItems(){
		return (List<Cart>) cr.findAll();
	}

	@Transactional
	public void addToCart(Item item) {
		System.out.println("service called");
		Cart cart = null;
		cart=cr.findCartItemByUserid(1);
		if(cart==null){	
			System.out.println("if block");
			List<Item> list=new ArrayList<Item>();
			list.add(item);
			cart= new Cart(1 , list);
			cr.save(cart);
		}else{	
			System.out.println("else block");
			int flag=0;
			for(Item i: cart.getList()){
				if(i.getId() == item.getId()){
					i.setQuantity(i.getQuantity()+item.getQuantity());
					ir.updateItemQuantity(i.getQuantity(), i.getId());
					flag=1;
					System.out.println("item added");
				}
			}
			if(flag==0){
				cart.getList().add(item);
				cr.save(cart);
			}			
		}		
	}
	
	@Transactional
	public List<Item> getCartItems() {
		Cart cart= cr.findCartItemByUserid(1);	
		System.out.println(cart.getList());
		return cart.getList();
	}
	@Transactional
	public int totalCost() {
		Cart cart= cr.findCartItemByUserid(1);
		int total=0;
		for(Item i: cart.getList()){
			System.out.println(i.getCost()*i.getQuantity());
			total= total+ (i.getCost()*i.getQuantity());
		}
		System.out.println(total);
		return total;
	}
	@Transactional
	public boolean updateCartItem(Item item) {
		Cart cart=cr.findCartItemByUserid(1);
		System.out.println(item.getQuantity());
		boolean value= false;
		for(Item i: cart.getList()){
			if(i.getId()==item.getId()){
				i.setQuantity(item.getQuantity());
				ir.updateItemQuantity(i.getQuantity(), i.getId());
				System.out.println("updating    "+i.getQuantity());
				value= true;
			}
		}
		return value;
	}
	
	@Transactional
	public boolean placeOrder() {
		Cart cart=cr.findCartItemByUserid(1);
		cr.delete(cart);
		for(Item item: cart.getList()){
			item.setAvail(item.getAvail()-item.getQuantity());
			ir.updateItem(item.getAvail(), item.getId());
		}
		return true;
	}


	
}