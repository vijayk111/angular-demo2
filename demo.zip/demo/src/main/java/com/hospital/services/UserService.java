package com.hospital.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hospital.Exception.UserAlreadyExistException;
import com.hospital.Exception.UserNotFoundException;
import com.hospital.model.User;
import com.hospital.model.UserRepository;

@Service
@Qualifier("userService")
public class UserService {
	
	@Autowired
	private UserRepository ur;
	
		
	@Transactional
	public boolean saveUser(User user) throws UserAlreadyExistException {
		boolean value=false;
		User existingUser = ur.findbyUsername(user.getUsername());
		if(!(existingUser==null)){
			throw new UserAlreadyExistException("User with username already exists");
		}
		else{
			ur.save(user);
			value= true;
		}
		return value;
	}
	
	public User findByUserIdAndPassword(String username, String password) throws UserNotFoundException {
		User user= ur.findbyUsername(username);
		System.out.println(user.getUsername());
		if(!(user == null) && (user.getPassword().equals(password))){
			System.out.println("details matched");
			return user;
		}else{
			throw new UserNotFoundException("Invalid Username/Password");			
		}
	}
	
}
